<?php

require './printutils.php';

println("It's like 'require'-ing modules!");
