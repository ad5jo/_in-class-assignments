var myPets = {
  cat: "Mr. Hyena",
  lizard: "Mr. Big Big",
  goat: "Wolf Who Ate Wall Street",
  pigeon: "Joan"
};


var myPetAnimals = ["cat", "lizard", "goat", "pigeon"];
var myPetNames = ["Mr. Hyena", "Mr. Big Big", "Wolf Who Ate Wall Street", "Joan"];
