DROP DATABASE IF EXISTS `sequelize_chirpy`;
CREATE DATABASE `sequelize_chirpy`;
