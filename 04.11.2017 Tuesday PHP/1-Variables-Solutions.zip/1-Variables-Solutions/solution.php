<?php

// Name information
$first = 'Peleke';
$last  = 'Sengstacke';
$full  = $first . $last;

// Age information
$birth_year = 1993;
$current_year = 2016;
$age = $current_year - $birth_year;

echo "My name is $full.\n";
echo "I am $age years old.\n";
