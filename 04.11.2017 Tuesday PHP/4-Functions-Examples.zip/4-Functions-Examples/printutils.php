<?php 

function println($string) {
  echo "$string\n";
}
