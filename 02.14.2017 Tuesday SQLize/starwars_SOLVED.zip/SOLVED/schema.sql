DROP DATABASE `starwars`;
CREATE DATABASE `starwars`;